jQuery(document).ready(function($) {
    /*$('.p-del').click(function(){
        var title = $(this).data('title');
        var id = $(this).data('id');
        var r = confirm("You like to delete " + title);
        if (r == true) {
        $.ajax({
            url: "demo_test.txt",
            data: {
                
            },
            success: function(result){
                $("#div1").html(result);
            }});
        }
    });*/
});