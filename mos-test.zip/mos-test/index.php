<?php
include('app.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</head>
<body>
  
<div class="container">
    <?php
    //SELECT * FROM `product` WHERE `status`!=
        $sql = "SELECT * FROM product";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) :
            // output data of each row
            while($row = $result->fetch_assoc()) :?>
                <h3 class="title"><?php echo $row["title"]?></h3>
                <div class="desc"><?php echo $row["description"]?></div>
                <a href="single.php?id=<?php echo $row["id"];?>">Review</a>
            <?php endwhile;        
        endif;
    ?>
</div>
<?php $conn->close(); ?>
</body>
</html>
