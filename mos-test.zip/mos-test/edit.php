<?php
$id = (@$_GET['id']) ? $_GET['id'] : 0;
include('app.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $err = 0;
    $titleErr = '';
    if (empty($_POST["title"])) {
        $titleErr = "Title is required";
        $err++;
    } else {
        $title = test_input($_POST["title"]);
    }
    $description = test_input($_POST["description"]);
    $status = test_input($_POST["status"]);
    //echo $err;
    if (!$err) {
        if ($_POST["action"] == 'update') {
            $id = test_input($_POST["id"]);
            $sql = "UPDATE product SET title='$title', description='$description', status='$status' WHERE id=".$id;
            $conn->query($sql);
        } else {
            $sql = "INSERT INTO product (title, description,status) VALUES ('$title', '$description', '$status')";
            $conn->query($sql);
            $id = $conn->insert_id;
            header('Location: edit.php?id='.$id);
        }
    }
}
if (@$id) {
    $sql = "SELECT * FROM product WHERE id=" . $id;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $title = $row["title"];
            $description = $row["description"];
            $status = $row["status"];
        }
    }    
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<!doctype html>
<html lang="en">
  <head>
    <title>Dashboard Template for Bootstrap</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/favicon.ico">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    
    <link href="css/dashboard.css" rel="stylesheet">
  </head>

  <body>
    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">Company name</a>
      <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="#">Sign out</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">

        <?php include('dashboard-sidebar.php')?>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2"><?php if ($id) echo "Update"; else echo "Add"?> Product</h1>
          </div>

          <div class="content-area">
            <form method="post" action="">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input name="title" type="text" class="form-control" id="title" placeholder="Enter title" value="<?php echo @$title ?>">
                </div>
                <div class="form-group">
                    <label for="details">Details</label>
                    <textarea name="description" class="form-control" id="description" rows="3"><?php echo @$description ?></textarea>
                </div>
                <div class="form-group">
                    <?php $status = (@$status) ? $status : 'publish'?>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="status" id="publish" value="publish" <?php if ($status == 'publish') echo 'checked' ?>>
                      <label class="form-check-label" for="publish">Publish</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="status" id="draft" value="draft">
                      <label class="form-check-label" for="draft" <?php if ($status == 'draft') echo 'checked' ?>>Draft</label>
                    </div>                    
                </div>
                <?php if ($id) : ?>
                <button name="action" type="submit" class="btn btn-primary" value="update">Update Product</button>
                <input type="hidden" name="id" value="<?php echo $id?>">
                <?php else : ?>
                <button name="action" type="submit" class="btn btn-primary" value="add">Add Product</button>
                <?php endif;?>
            </form>
          </div>
        </main>
      </div>
    </div>

  </body>
</html>
