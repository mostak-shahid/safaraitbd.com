<?php
$id = (@$_GET['id']) ? $_GET['id'] : 0;

include('app.php');
$rating_arr = array(
    '0' => 'worst',
    '1' => 'worse',
    '2' => 'bad',
    '3' => 'good',
    '4' => 'better',
    '5' => 'best'
);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   if ($_POST["submit"] == 'comment-post') {
       $rating = ($_POST['rating']) ? $_POST['rating'] : 0;
       $comment = ($_POST['comment']) ? $_POST['comment'] : '';
       $lowercomment = strtolower($comment);
       $slices = explode(' ', $lowercomment);
       //var_dump($slices);
       foreach($slices as $word){
           $word = preg_replace("/[^a-zA-Z]/", "", $word);
           foreach ($rating_arr as $key => $value) {
               if ($word == $value) {
                   $rating = $rating + $key;
               }
           }
       }
       //UPDATE `product` SET `rating`=[value-4] WHERE `id`
       $sql = "UPDATE product SET rating={$rating} WHERE id=" . $id;
       $conn->query($sql);
       //echo $rating;
   }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</head>
<body>
  
<div class="container">
<!--         SELECT * FROM `product` WHERE `id`=1    -->
<?php
    if ($id) :
        $sql = "SELECT * FROM product WHERE id=" . $id;
        $result = $conn->query($sql);
        if ($result->num_rows > 0) :
            // output data of each row
            while($row = $result->fetch_assoc()) :?>
                <h3 class="title"><?php echo $row["title"]?></h3>
                <div class="desc"><?php echo $row["description"]?></div>
                <span class="rating"><?php echo $row["rating"]?></span>
                <form action="" method="post">
                    <div class="form-group">
                        <label for="comment">Reiew</label>
                        <textarea name="comment" class="form-control" id="comment" rows="3"></textarea>
                        <input type="hidden" name="rating" value="<?php echo $row["rating"]?>" />
                    </div>
                    <button name="submit" type="submit" class="btn btn-primary" value="comment-post">Submit</button>
                </form>
            <?php endwhile;        
        endif;
    endif;
$conn->close();    
?>
</div>

</body>
</html>
