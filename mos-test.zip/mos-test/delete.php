<?php
$id = $_GET['id'];
include('app.php');
$sql = "DELETE FROM product WHERE id=" . $id;
if ($conn->query($sql) === TRUE) {
    header('Location: products.php');
}